import './css/index.css';
import aa from './assets/aa.png';
import add from './a';
console.log(1);
eval(`let a =10;let b= 20; console.log(a+b)`);
console.log('index,', add(1, 6));


let fn = ()=>{};
fn();

@log
class A {
  a = 1;
}

function log(target) {
  console.log(target === A);
}


let oApp = document.getElementById('app');

let image = new Image();
image.src = aa;
image.height = 200;
oApp.appendChild(image);


