function add(num1, num2) {
  return num1 + num2;
}

class B {
  b = 20;
}

export default add;

// module.exports = add;