export const add = (n1, n2) => {
  console.log('add~~~~');
  return n1 + n2};
const minus = (n1, n2) => {
  console.log('minus~~~~');
  return n1 - n2};

